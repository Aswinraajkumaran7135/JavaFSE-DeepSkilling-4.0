public class Razorpay {
    public void pay(double amount) {
        System.out.println("Payment of ₹" + amount + " processed via Razorpay.");
    }
}