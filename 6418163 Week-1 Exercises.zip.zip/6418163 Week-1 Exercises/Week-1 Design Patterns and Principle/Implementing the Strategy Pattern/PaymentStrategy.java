public interface PaymentStrategy {
    void pay(String amount);
}