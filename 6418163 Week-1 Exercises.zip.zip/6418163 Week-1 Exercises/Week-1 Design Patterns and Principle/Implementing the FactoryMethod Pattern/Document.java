public interface Document {
    void open();
}